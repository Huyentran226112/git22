<?php include_once '../db.php'; ?>
<?php

?>
<?php include_once '../header.php'; ?>
<div class="container-fluid px-4">

</div>
<?php include_once '../footer.php'; ?>